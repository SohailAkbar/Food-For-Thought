
<!-- copy -->
<div class="copy-right">
	<div class="container">
		<div class="copy-lt">
			<p> &copy; <?php echo date('Y');?> @ Food Wastage Management System </p>
		</div>
		<div class="copy-rt">
			<ul>
				<li><a class="facebook" href="#"></a></li>
				<li><a class="twitt" href="#"></a></li>
				<li><a class="link" href="#"></a></li>
				<li><a class="googl" href="#"></a></li>
				<li><a class="dribb" href="#"></a></li>
			</ul>
		</div>
		<div class="clearfix"></div>
	</div>
</div>
<!-- copy -->